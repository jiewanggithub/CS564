#include "heapfile.h"
#include "error.h"

// routine to create a heapfile
const Status createHeapFile(const string fileName)
{
    File* 		file;
    Status 		status;
    FileHdrPage*	hdrPage;
    int			hdrPageNo;
    int			newPageNo;
    Page*		newPage;

    // try to open the file. This should return an error
    status = db.openFile(fileName, file);
    if (status != OK)
    {
		// file doesn't exist. First create it and allocate
		// an empty header page and data page.
		status = db.createFile(fileName);
        if (status != OK)
            return status;

        // Open the newly created file.
        status = db.openFile(fileName, file);
        if (status != OK)
            return status;

        // Allocate a new page for the file header.
        status = bufMgr->allocPage(file, hdrPageNo, newPage);
        if (status != OK)
            return status;

        // Cast the allocated page as a header page.
        hdrPage = (FileHdrPage*) newPage;

        // Copy the file name into the header page and add a null terminator.
        int length = fileName.size();
        for (int i = 0; i < length; ++i) {
            hdrPage->fileName[i] = fileName[i];
        }
        hdrPage->fileName[length] = '\0';

        // Initialize header page metadata.
        hdrPage->firstPage = 0;
        hdrPage->lastPage = 0;
        hdrPage->pageCnt = 0;
        hdrPage->recCnt = 0;

        // Allocate the first data page.
        status = bufMgr->allocPage(file, newPageNo, newPage);
        if (status != OK)
            return status;

        // Initialize the contents of the new data page.
        newPage->init(newPageNo);
        newPage->setNextPage(-1);  // Set end-of-file marker.

        // Update the header page with the new data page information.
        hdrPage->firstPage = newPageNo;
        hdrPage->lastPage = newPageNo;
        hdrPage->pageCnt = 1;
        hdrPage->recCnt = 0;

        // Unpin the header page and data page, marking them as modified.
        status = bufMgr->unPinPage(file, hdrPageNo, true);
        if (status != OK)
            return status;

        status = bufMgr->unPinPage(file, newPageNo, true);
        if (status != OK)
            return status;

        // Close the file after setup is complete.
        status = db.closeFile(file);
        if (status != OK)
            return status;

        return OK;  // Successfully created the heap file.		
    }
    return (FILEEXISTS);
}

// routine to destroy a heapfile
const Status destroyHeapFile(const string fileName)
{
	return (db.destroyFile (fileName));
}

// constructor opens the underlying file
HeapFile::HeapFile(const string & fileName, Status& returnStatus)
{
    Status 	status;
    Page*	pagePtr;

    cout << "opening file " << fileName << endl;

    // open the file and read in the header page and the first data page
    if ((status = db.openFile(fileName, filePtr)) == OK)
    {
		File* file = filePtr;

        // Retrieve the page number of the header page.
        int pageNo = -1;
        status = file->getFirstPage(pageNo);
        if (status != OK) {
            returnStatus = status;
            return;
        }

        // Read the header page into memory.
        Page* page_ptr;
        status = bufMgr->readPage(file, pageNo, page_ptr);
        if (status != OK) {
            returnStatus = status;
            return;
        }

        // Cast the read page to a header page and set relevant attributes.
        headerPage = reinterpret_cast<FileHdrPage*>(page_ptr);
        headerPageNo = pageNo;
        hdrDirtyFlag = false;

        // Retrieve and read the first data page.
        int firstPageNo = headerPage->firstPage;
        status = bufMgr->readPage(file, firstPageNo, page_ptr);
        if (status != OK) {
            returnStatus = status;
            return;
        }

        // Initialize the attributes for the current page.
        curPage = page_ptr;
        curPageNo = firstPageNo;
        curDirtyFlag = false;

        // Initialize the current record ID to NULL.
        curRec = NULLRID;

        // Indicate successful initialization.
        returnStatus = OK;
        return;
    }
    else
    {
    	cerr << "open of heap file failed\n";
		returnStatus = status;
		return;
    }
}

// the destructor closes the file
HeapFile::~HeapFile()
{
    Status status;
    cout << "invoking heapfile destructor on file " << headerPage->fileName << endl;

    // see if there is a pinned data page. If so, unpin it 
    if (curPage != NULL)
    {
    	status = bufMgr->unPinPage(filePtr, curPageNo, curDirtyFlag);
		curPage = NULL;
		curPageNo = 0;
		curDirtyFlag = false;
		if (status != OK) cerr << "error in unpin of date page\n";
    }
	
	 // unpin the header page
    status = bufMgr->unPinPage(filePtr, headerPageNo, hdrDirtyFlag);
    if (status != OK) cerr << "error in unpin of header page\n";
	
	// status = bufMgr->flushFile(filePtr);  // make sure all pages of the file are flushed to disk
	// if (status != OK) cerr << "error in flushFile call\n";
	// before close the file
	status = db.closeFile(filePtr);
    if (status != OK)
    {
		cerr << "error in closefile call\n";
		Error e;
		e.print (status);
    }
}

// Return number of records in heap file

const int HeapFile::getRecCnt() const
{
  return headerPage->recCnt;
}

// retrieve an arbitrary record from a file.
// if record is not on the currently pinned page, the current page
// is unpinned and the required page is read into the buffer pool
// and pinned.  returns a pointer to the record via the rec parameter

const Status HeapFile::getRecord(const RID & rid, Record & rec)
{
    Status status;

    // cout<< "getRecord. record (" << rid.pageNo << "." << rid.slotNo << ")" << endl;
    // Check if the requested page is already pinned (current page).
    if (rid.pageNo == curPageNo) {
        // Attempt to retrieve the record from the current page.
        status = curPage->getRecord(rid, rec);
    } else {
        // The requested page is not the current page.

        // Unpin the currently pinned page.
        status = bufMgr->unPinPage(filePtr, curPageNo, curPage);
        if (status != OK)
            return status;

        // Read the requested page into memory.
        status = bufMgr->readPage(filePtr, rid.pageNo, curPage);
        if (status != OK)
            return status;

        // Update the current page number and reset the dirty flag.
        curPageNo = rid.pageNo;
        curDirtyFlag = false;

        // Attempt to retrieve the record from the newly loaded page.
        status = curPage->getRecord(rid, rec);
    }

    // Return the status of the operation.
    return status;
}

HeapFileScan::HeapFileScan(const string & name,
			   Status & status) : HeapFile(name, status)
{
    filter = NULL;
}

const Status HeapFileScan::startScan(const int offset_,
				     const int length_,
				     const Datatype type_, 
				     const char* filter_,
				     const Operator op_)
{
    if (!filter_) {                        // no filtering requested
        filter = NULL;
        return OK;
    }
    
    if ((offset_ < 0 || length_ < 1) ||
        (type_ != STRING && type_ != INTEGER && type_ != FLOAT) ||
        (type_ == INTEGER && length_ != sizeof(int)
         || type_ == FLOAT && length_ != sizeof(float)) ||
        (op_ != LT && op_ != LTE && op_ != EQ && op_ != GTE && op_ != GT && op_ != NE))
    {
        return BADSCANPARM;
    }

    offset = offset_;
    length = length_;
    type = type_;
    filter = filter_;
    op = op_;

    return OK;
}


const Status HeapFileScan::endScan()
{
    Status status;
    // generally must unpin last page of the scan
    if (curPage != NULL)
    {
        status = bufMgr->unPinPage(filePtr, curPageNo, curDirtyFlag);
        curPage = NULL;
        curPageNo = 0;
		curDirtyFlag = false;
        return status;
    }
    return OK;
}

HeapFileScan::~HeapFileScan()
{
    endScan();
}

const Status HeapFileScan::markScan()
{
    // make a snapshot of the state of the scan
    markedPageNo = curPageNo;
    markedRec = curRec;
    return OK;
}

const Status HeapFileScan::resetScan()
{
    Status status;
    if (markedPageNo != curPageNo) 
    {
		if (curPage != NULL)
		{
			status = bufMgr->unPinPage(filePtr, curPageNo, curDirtyFlag);
			if (status != OK) return status;
		}
		// restore curPageNo and curRec values
		curPageNo = markedPageNo;
		curRec = markedRec;
		// then read the page
		status = bufMgr->readPage(filePtr, curPageNo, curPage);
		if (status != OK) return status;
		curDirtyFlag = false; // it will be clean
    }
    else curRec = markedRec;
    return OK;
}


const Status HeapFileScan::scanNext(RID& outRid)
{
    Status 	status = OK;
    RID		nextRid;
    RID		tmpRid;
    int 	nextPageNo;
    Record      rec;

    // Continue scanning while there are pages to process.
    while (curPageNo != -1) {
        // Start searching for the next record from the current record.
        tmpRid = curRec;
        status = curPage->nextRecord(tmpRid, nextRid);

        // If no more records are found on the current page.
        if (status != OK) {
            // Check if the current page is the last page in the file.
            if (curPageNo == headerPage->lastPage) {
                return FILEEOF; // End of the file reached.
            }

            // Move to the next page.
            status = curPage->getNextPage(nextPageNo);
            if (status != OK) {
                return status; // Return any error encountered.
            }

            // Unpin the current page.
            status = bufMgr->unPinPage(filePtr, curPageNo, curDirtyFlag);
            if (status != OK) {
                return status;
            }

            // Load the next page into memory.
            status = bufMgr->readPage(filePtr, nextPageNo, curPage);
            if (status != OK) {
                return status;
            }

            // Update the current page number and reset the dirty flag.
            curPageNo = nextPageNo;
            curDirtyFlag = false;

            // Start from the first record on the new page.
            status = curPage->firstRecord(nextRid);
        }

        // If a record is successfully found or another status (other than NORECORDS) is returned.
        if (status == OK || status != NORECORDS) {
            // Retrieve the record data associated with the RID.
            status = curPage->getRecord(nextRid, rec);
            if (status != OK) {
                return status;
            }

            // Update the current record to the newly found one.
            curRec = nextRid;

            // Check if the record matches the scan criteria.
            if (matchRec(rec)) {
                outRid = curRec; // Output the matched record's RID.
                return status;
            }
        }
    }

    // Return OK if no further records are found matching the criteria.
    return OK;
}


// returns pointer to the current record.  page is left pinned
// and the scan logic is required to unpin the page 

const Status HeapFileScan::getRecord(Record & rec)
{
    return curPage->getRecord(curRec, rec);
}

// delete record from file. 
const Status HeapFileScan::deleteRecord()
{
    Status status;

    // delete the "current" record from the page
    status = curPage->deleteRecord(curRec);
    curDirtyFlag = true;

    // reduce count of number of records in the file
    headerPage->recCnt--;
    hdrDirtyFlag = true; 
    return status;
}


// mark current page of scan dirty
const Status HeapFileScan::markDirty()
{
    curDirtyFlag = true;
    return OK;
}

const bool HeapFileScan::matchRec(const Record & rec) const
{
    // no filtering requested
    if (!filter) return true;

    // see if offset + length is beyond end of record
    // maybe this should be an error???
    if ((offset + length -1 ) >= rec.length)
	return false;

    float diff = 0;                       // < 0 if attr < fltr
    switch(type) {

    case INTEGER:
        int iattr, ifltr;                 // word-alignment problem possible
        memcpy(&iattr,
               (char *)rec.data + offset,
               length);
        memcpy(&ifltr,
               filter,
               length);
        diff = iattr - ifltr;
        break;

    case FLOAT:
        float fattr, ffltr;               // word-alignment problem possible
        memcpy(&fattr,
               (char *)rec.data + offset,
               length);
        memcpy(&ffltr,
               filter,
               length);
        diff = fattr - ffltr;
        break;

    case STRING:
        diff = strncmp((char *)rec.data + offset,
                       filter,
                       length);
        break;
    }

    switch(op) {
    case LT:  if (diff < 0.0) return true; break;
    case LTE: if (diff <= 0.0) return true; break;
    case EQ:  if (diff == 0.0) return true; break;
    case GTE: if (diff >= 0.0) return true; break;
    case GT:  if (diff > 0.0) return true; break;
    case NE:  if (diff != 0.0) return true; break;
    }

    return false;
}

InsertFileScan::InsertFileScan(const string & name,
                               Status & status) : HeapFile(name, status)
{
  //Do nothing. Heapfile constructor will bread the header page and the first
  // data page of the file into the buffer pool
}

InsertFileScan::~InsertFileScan()
{
    Status status;
    // unpin last page of the scan
    if (curPage != NULL)
    {
        status = bufMgr->unPinPage(filePtr, curPageNo, true);
        curPage = NULL;
        curPageNo = 0;
        if (status != OK) cerr << "error in unpin of data page\n";
    }
}

// Insert a record into the file
const Status InsertFileScan::insertRecord(const Record & rec, RID& outRid)
{
    Page*	newPage;
    int		newPageNo;
    Status	status, unpinstatus;
    RID		rid;

    // check for very large records
    if ((unsigned int) rec.length > PAGESIZE-DPFIXED)
    {
        // will never fit on a page, so don't even bother looking
        return INVALIDRECLEN;
    }

    // If no current page is set, set the last page of the file as the current page.
    if (curPage == NULL) {
        // Unpin the current page if necessary.
        unpinstatus = bufMgr->unPinPage(filePtr, curPageNo, curDirtyFlag);
        if (unpinstatus != OK && unpinstatus != PAGENOTPINNED) {
            return unpinstatus;
        }
        curPage = NULL;
        curPageNo = 0;
        curDirtyFlag = false;

        // Load the last page of the file into memory.
        status = bufMgr->readPage(filePtr, headerPage->lastPage, curPage);
        if (status != OK) {
            return status;
        }

        // Update the current page to the last page.
        curPageNo = headerPage->lastPage;
    }

    // Attempt to insert the record into the current page.
    status = curPage->insertRecord(rec, outRid);

    // If the current page does not have enough space for the record:
    if (status == NOSPACE) {
        // Allocate a new page.
        status = bufMgr->allocPage(filePtr, newPageNo, newPage);
        if (status != OK) {
            return status;
        }

        // Initialize the new page.
        newPage->init(newPageNo);

        // Update the current page's next page pointer to point to the new page.
        curPage->setNextPage(newPageNo);

        // Unpin the current page.
        status = bufMgr->unPinPage(filePtr, curPageNo, curDirtyFlag);
        if (status != OK) {
            return status;
        }

        // Update the current page to the newly allocated page.
        curDirtyFlag = false;
        curPage = newPage;
        curPageNo = newPageNo;

        // Insert the record into the new page.
        status = curPage->insertRecord(rec, outRid);
        if (status != OK) {
            return status;
        }

        // Update the header page to reflect the addition of the new page.
        headerPage->pageCnt += 1;
        headerPage->lastPage = curPageNo;
        hdrDirtyFlag = true;
    }

    // Mark the current page as modified and update record counts.
    curDirtyFlag = true;
    headerPage->recCnt += 1;
    curRec = outRid;

    // Return the status of the operation.
    return status;
}


